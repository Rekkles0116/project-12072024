<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="home.css">
  <title>Trending</title>
</head>
<body>
  <div class="vertical-menu">
    <div class="menu-header">
      <a href="home.html">
        <img src="image/project logo.png" alt="Logo" class="logo">
      </a>
    </div>
    <a href="home.php" ><i class="fas fa-home"></i> Home</a>
    <a href="trending.php" class="active"><i class="fas fa-chart-line"></i> Trending</a>
    <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
  </div>
  <div class="top-bar">
    <input type="text" placeholder="Search Discussion" class="search-bar">
    
    <a href="create.html" class="create-container">
      <img src="image/edit.png" alt="create" class="create">
      <span>Create</span>
    </a>
    <i class="fas fa-user profile-icon"> lee yong</i>
  </div>
  <div class="filter">
   
  </div>

  <div class="content">
    <button class="filter-button"><i class="fas fa-filter"></i> Filter</button>
    
    <div class="forum-discussion">
      <div class="gold">
        <img src="image/gold.png" class="gold">
      </div>
    <div class="subforum-avatar">
        <i class="fas fa-user profile-icon"> lee yong</i>
        
    </div>

    <div class="subforum-date">
        <small>Posted on 22 Dec 2024</small>
        
    </div>
    <div class="description">
        <h1>Description title</h1>
    </div>
    <div class="subforum-description">
        <p>content hereeeeeeeeeeeeeeeeeee.</p>
    
        <ul>
          <li>List item 1</li>
          <li>List item 2</li>
          <li>List item 3</li>
        </ul>

    </div>
    
  </div>


  <div class="forum-discussion">
    <div class="silver">
      <img src="image/silver.png" class="silver">
    </div>
    <div class="subforum-avatar">
        <i class="fas fa-user profile-icon"> lee yong</i>
    </div>
    <div class="subforum-date">
        <small>Posted on 22 Dec 2024</small>
    </div>
    <div class="description">
        <h1>Description title</h1>
    </div>
    <div class="subforum-description">
        <p>content hereeeeeeeeeeeeeeeeeee.</p>
    
        <ul>
          <li>List item 1</li>
          <li>List item 2</li>
          <li>List item 3</li>
        </ul>

    </div>

    
  </div>

  <div class="forum-discussion">
    <div class="bronze">
      <img src="image/bronze.png" class="bronze">
    </div>
    <div class="subforum-avatar">
        <i class="fas fa-user profile-icon"> lee yong</i>
    </div>

    <div class="subforum-date">
        <small>Posted on 22 Dec 2024</small>
    </div>
    <div class="description">
        <h1>Description title</h1>
    </div>
    <div class="subforum-description">
        <p>content hereeeeeeeeeeeeeeeeeee.</p>
    
        <ul>
          <li>List item 1</li>
          <li>List item 2</li>
          <li>List item 3</li>
        </ul>

    </div>
</div>




    
</body>

</html>
