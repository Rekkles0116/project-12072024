<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "forum");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $author = "lee yong"; // Replace with actual author identification logic
    $imagePath = '';

    // Handle file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $imageDir = 'uploads/';
        $imagePath = $imageDir . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }

    $sql = "INSERT INTO discussions (title, content, author, image_path) VALUES ('$title', '$content', '$author', '$imagePath')";
    if ($conn->query($sql) === TRUE) {
        header("Location: discussion.php?id=" . $conn->insert_id);
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Discussion</title>
</head>
<body>
    <h1>Create a New Discussion</h1>
    <form action="create.php" method="post" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br><br>
        
        <label for="content">Content:</label>
        <textarea id="content" name="content" rows="4" required></textarea><br><br>
        
        <label for="image">Upload Image:</label>
        <input type="file" id="image" name="image" accept="image/*"><br><br>
        
        <button type="submit">Create</button>
    </form>
</body>
</html>
